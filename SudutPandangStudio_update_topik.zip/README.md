# Sudut Pandang Studio — Prototipe V1

Ini adalah **kode sumber awal**, bukan APK siap instal.

## Isi prototipe
- Dashboard Android sederhana dengan tema gelap dan aksen emas.
- Membuat dan menyimpan nama proyek secara lokal.
- Kerangka awal untuk pengembangan fitur naskah, storyboard, visual, audio, subtitle, dan ekspor.

## Persyaratan build
- Android Studio
- Android SDK 35
- JDK 17
- Gradle yang sesuai dengan Android Gradle Plugin 8.6.1

## Catatan
Fitur AI, impor berkas, editor video, dan render MP4 belum diimplementasikan.
