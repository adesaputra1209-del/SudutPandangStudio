package id.sudutpandang.studio

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val gold = 0xFFD6AD55.toInt()
    private val white = 0xFFF4F0E8.toInt()
    private val muted = 0xFFBBBBBB.toInt()
    private val panel = 0xFF242424.toInt()
    private val prefs by lazy { getSharedPreferences("studio", MODE_PRIVATE) }
    private val projects = mutableListOf<String>()
    private lateinit var projectList: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showDashboard()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(22), dp(28), dp(22), dp(24))
        setBackgroundColor(0xFF101010.toInt())
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
    }

    private fun actionButton(value: String, primary: Boolean = false, action: () -> Unit) = Button(this).apply {
        text = value
        setTextColor(if (primary) 0xFF17140D.toInt() else gold)
        if (primary) setBackgroundColor(gold) else setBackgroundColor(panel)
        setOnClickListener { action() }
    }

    private fun showDashboard() {
        val root = base()
        root.addView(label("SUDUT PANDANG\nSTUDIO", 27f, gold, true).apply { gravity = Gravity.CENTER })
        root.addView(label("Membuka Fakta, Melihat Sejarah", 13f, muted).apply { gravity = Gravity.CENTER })
        root.addView(label("\nCeritakan peristiwa.\nTampilkan sudut pandangnya.", 21f, white, true))
        root.addView(actionButton("+ Buat Proyek Baru", true) { createProject() }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16); bottomMargin = dp(10) })
        root.addView(actionButton("TOPIK DOKUMENTER  ›") { showTopics() }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(22) })
        root.addView(label("PROYEK SAYA", 14f, gold, true))
        projectList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(projectList)
        setContentView(ScrollView(this).apply { addView(root) })
        refreshProjects()
    }

    private fun createProject() {
        val input = EditText(this).apply { hint = "Contoh: Tragedi Westerling"; setTextColor(white); setHintTextColor(muted) }
        AlertDialog.Builder(this).setTitle("Buat Proyek").setMessage("Masukkan judul proyek dokumenter.")
            .setView(input).setNegativeButton("Batal", null).setPositiveButton("Simpan") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    val current = prefs.getStringSet("projects", emptySet())?.toMutableSet() ?: mutableSetOf()
                    current.add(name)
                    prefs.edit().putStringSet("projects", current).apply()
                    refreshProjects()
                    Toast.makeText(this, "Proyek tersimpan", Toast.LENGTH_SHORT).show()
                } else Toast.makeText(this, "Judul belum diisi", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun refreshProjects() {
        projects.clear()
        projects.addAll(prefs.getStringSet("projects", emptySet()) ?: emptySet())
        projectList.removeAllViews()
        if (projects.isEmpty()) projectList.addView(label("Belum ada proyek. Buat proyek baru untuk memulai.", 13f, muted))
        projects.sorted().forEach { name ->
            projectList.addView(actionButton(name) {
                AlertDialog.Builder(this).setTitle(name)
                    .setMessage("Proyek tersimpan di perangkat ini. Modul naskah, storyboard, visual, audio, dan ekspor akan ditambahkan bertahap.")
                    .setPositiveButton("Tutup", null).show()
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
    }

    private fun showTopics() {
        val root = base()
        root.addView(actionButton("‹ KEMBALI") { showDashboard() })
        root.addView(label("TOPIK DOKUMENTER", 23f, gold, true).apply { setPadding(0, dp(22), 0, dp(8)) })
        root.addView(label("Tulis topik yang ingin kamu angkat. Topik akan disimpan di HP ini.", 14f, muted))
        val input = EditText(this).apply {
            hint = "Contoh: Tragedi Westerling di Sulawesi Selatan"
            setTextColor(white); setHintTextColor(muted)
            setText(prefs.getString("documentary_topic", "") ?: "")
            minLines = 3; gravity = Gravity.TOP
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(panel)
        }
        root.addView(input, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18); bottomMargin = dp(12) })
        root.addView(actionButton("SIMPAN TOPIK", true) {
            val topic = input.text.toString().trim()
            if (topic.isEmpty()) {
                Toast.makeText(this, "Tulis topik terlebih dahulu", Toast.LENGTH_SHORT).show()
            } else {
                prefs.edit().putString("documentary_topic", topic).apply()
                Toast.makeText(this, "Topik berhasil disimpan", Toast.LENGTH_SHORT).show()
                showTopics()
            }
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })
        root.addView(label("CONTOH TOPIK", 13f, gold, true))
        listOf("Tragedi Westerling di Sulawesi Selatan", "Kejahatan perang Unit 731", "Misteri pembunuhan Hinterkaifeck", "Pembantaian Oradour-sur-Glane").forEach { example ->
            root.addView(actionButton(example) { input.setText(example); input.setSelection(input.text.length) }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
        val saved = prefs.getString("documentary_topic", "") ?: ""
        if (saved.isNotBlank()) {
            root.addView(label("\nTOPIK TERSIMPAN", 13f, gold, true))
            root.addView(label(saved, 15f, white))
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
