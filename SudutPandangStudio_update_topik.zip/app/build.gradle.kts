plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "id.sudutpandang.studio"
    compileSdk = 35
    defaultConfig {
        applicationId = "id.sudutpandang.studio"
        minSdk = 28
        targetSdk = 28
        versionCode = 1
        versionName = "1.0-prototype"
    }
}
