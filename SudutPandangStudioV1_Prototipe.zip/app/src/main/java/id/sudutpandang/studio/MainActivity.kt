package id.sudutpandang.studio

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val projects = mutableListOf<String>()
    private lateinit var list: LinearLayout
    private val gold = 0xFFD6AD55.toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(0xFF101010.toInt())
        }
        val title = TextView(this).apply {
            text = "SUDUT PANDANG\nSTUDIO"
            textSize = 27f
            setTextColor(gold)
            gravity = Gravity.CENTER
        }
        val tagline = TextView(this).apply {
            text = "Membuka Fakta, Melihat Sejarah"
            textSize = 13f
            setTextColor(0xFFCCCCCC.toInt())
            gravity = Gravity.CENTER
        }
        val add = Button(this).apply {
            text = "+ Buat Proyek Baru"
            setOnClickListener { createProject() }
        }
        val heading = TextView(this).apply {
            text = "Proyek Saya"
            textSize = 20f
            setTextColor(gold)
            setPadding(0, 28, 0, 12)
        }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(title)
        root.addView(tagline)
        root.addView(add)
        root.addView(heading)
        root.addView(list)
        setContentView(root)
        refresh()
    }
    private fun createProject() {
        val input = EditText(this).apply { hint = "Contoh: Tragedi Westerling" }
        AlertDialog.Builder(this)
            .setTitle("Buat Proyek")
            .setView(input)
            .setPositiveButton("Simpan") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    projects.add(name)
                    getSharedPreferences("studio", MODE_PRIVATE).edit()
                        .putStringSet("projects", projects.toSet()).apply()
                    refresh()
                }
            }
            .setNegativeButton("Batal", null).show()
    }
    private fun refresh() {
        projects.clear()
        projects.addAll(getSharedPreferences("studio", MODE_PRIVATE)
            .getStringSet("projects", emptySet()) ?: emptySet())
        list.removeAllViews()
        if (projects.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Belum ada proyek. Tekan tombol di atas untuk memulai."
                setTextColor(0xFFBBBBBB.toInt())
            })
        } else projects.forEach { name ->
            list.addView(Button(this).apply {
                text = name
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle(name)
                        .setMessage("Area kerja prototipe: naskah, storyboard, visual, audio, subtitle, dan ekspor akan dikembangkan pada tahap berikutnya.")
                        .setPositiveButton("Tutup", null).show()
                }
            })
        }
    }
}
